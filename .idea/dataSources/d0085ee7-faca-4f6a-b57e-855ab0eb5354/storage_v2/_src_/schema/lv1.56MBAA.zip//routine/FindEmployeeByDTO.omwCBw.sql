create
    definer = buicong@`%` procedure FindEmployeeByDTO(IN id_input int, IN age_input int)
begin
	select * from employee where id = id_input and age = age_input;
end;

